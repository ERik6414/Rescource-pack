# DivineLeaderboard – Fix für die Ausrichtung

## Änderung
Das Hologramm nutzt jetzt `Display.Billboard.CENTER` statt `FIXED`. Dadurch dreht sich das Leaderboard zum Betrachter, sodass es beim Umsehen nicht mehr seitlich wegzeigt.

## Plugin bauen
Die JAR konnte in dieser Umgebung nicht gebaut werden, weil Maven nicht installiert ist.
Auf einem Rechner mit Java 21 und Maven im Ordner des Plugins ausführen:

```bash
mvn clean package
```

Danach `target/DivineLeaderboard-1.0.0.jar` in den `plugins`-Ordner legen und den Server neu starten.

## Resourcepack
Das vorhandene Resourcepack bleibt unverändert, da die Glyphen und PNGs bereits vorhanden sind. Das Problem mit der Blickrichtung wird im Plugin behoben.
