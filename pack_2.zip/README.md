# DivineLeaderboard

`/stats` (Custom-GUI) und `/leaderboard` (Hologramm) fuer Kills, Tode, Money (Vault) und Gems.
Benoetigt das **erweiterte Resource Pack** (`pack_2_leaderboard.zip`), sonst sieht man nur Glyphen-Muell.

## Bauen
```
mvn clean package
```
Jar: `target/DivineLeaderboard-1.0.0.jar` -> in `plugins/`.
Server-Version in der `pom.xml` anpassen (`paper.version`, `java.version`).
Voraussetzung: Paper + Vault + ein Economy-Plugin. Optional: PlaceholderAPI.

## Befehle
| Befehl | Rechte | Was |
|---|---|---|
| `/stats [spieler]` | `divinestats.use` (alle) | Menue mit Kategorien Kills / Tode / Money / Gems, Klick = Top 10 |
| `/leaderboard spawn <kills\|deaths\|money\|gems>` | `divinestats.leaderboard` (OP) | Hologramm vor dir erstellen (schaut dich an) |
| `/leaderboard remove [id]` | dito | naechstes Board (8 Bloecke) bzw. per ID entfernen |
| `/leaderboard list` / `reload` | dito | auflisten / Config neu laden |
| `/statsadmin <set\|add> <kills\|deaths\|gems> <spieler> <menge>` | `divinestats.admin` | Werte manuell aendern |

## Gems
Es gibt kein Standard-Gem-System, daher zwei Modi (`config.yml` -> `gems.source`):
* `internal`: Gems speichert dieses Plugin. Aendern per `/statsadmin` oder aus Java: `DivineLeaderboardPlugin.get().stats().addGems(uuid, 50)`.
* `placeholder`: Wert kommt aus einem PlaceholderAPI-Platzhalter, z.B. `%playerpoints_points%` oder dem deines Gem-Plugins.

## Daten
SQLite: `plugins/DivineLeaderboard/stats.db`. Hologramme: `boards.yml`.
Money wird fuer Online-Spieler alle 60 s eingelesen, Offline-Spieler beim Start und alle 30 min (damit sie im Money-Ranking stehen).
Kills/Tode zaehlen nur bei Spieler-Kills (`PlayerDeathEvent`, Killer = Spieler).

## Hologramm-Hoehe
Falls ein Board bei dir zu hoch/tief haengt: `leaderboard.y-offset` in der config aendern, dann `/leaderboard reload`.
