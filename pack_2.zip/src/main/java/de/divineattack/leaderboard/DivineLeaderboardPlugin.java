package de.divineattack.leaderboard;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class DivineLeaderboardPlugin extends JavaPlugin {
    private static DivineLeaderboardPlugin instance;
    private StatsManager stats;
    private StatsGui gui;
    private LeaderboardManager boards;

    public static DivineLeaderboardPlugin get() {
        return instance;
    }

    public StatsManager stats() {
        return stats;
    }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        TextUtil.currency = getConfig().getString("money.symbol", "$");

        stats = new StatsManager(this);
        stats.load();
        gui = new StatsGui(stats);
        boards = new LeaderboardManager(this, stats);
        boards.load();

        Bukkit.getPluginManager().registerEvents(new StatsListener(this, stats), this);
        Bukkit.getPluginManager().registerEvents(gui, this);

        bind("stats", new StatsCommand(stats, gui));
        bind("leaderboard", new LeaderboardCommand(this, boards));
        bind("statsadmin", new StatsAdminCommand(stats));

        // Economy-Plugin kann nach uns laden -> erst einen Tick spaeter einlesen
        Bukkit.getScheduler().runTask(this, () -> {
            if (!stats.hasEconomy()) getLogger().warning("Keine Vault-Economy gefunden - Money-Stats bleiben leer!");
            stats.refreshOnline();
            if (getConfig().getBoolean("money.scan-offline-on-start", true)) stats.scanOffline();
            boards.start();
        });

        long interval = Math.max(10, getConfig().getInt("update-interval-seconds", 60)) * 20L;
        Bukkit.getScheduler().runTaskTimer(this, stats::refreshOnline, interval, interval);
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, stats::saveDirty, 20L * 60, 20L * 60);

        int rescan = getConfig().getInt("money.rescan-offline-minutes", 30);
        if (rescan > 0) {
            long t = rescan * 60L * 20L;
            Bukkit.getScheduler().runTaskTimer(this, stats::scanOffline, t, t);
        }
    }

    @Override
    public void onDisable() {
        if (boards != null) boards.shutdown();
        if (stats != null) stats.saveDirty();
    }

    private void bind(String name, Object handler) {
        PluginCommand cmd = getCommand(name);
        if (cmd == null) return;
        cmd.setExecutor((org.bukkit.command.CommandExecutor) handler);
        if (handler instanceof org.bukkit.command.TabCompleter tc) cmd.setTabCompleter(tc);
    }
}
