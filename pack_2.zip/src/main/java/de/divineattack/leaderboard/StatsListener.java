package de.divineattack.leaderboard;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Zaehlt Tode/Kills auf ZWEI Wegen, damit es auch auf Servern mit eigenem Todes-System (Instant-Respawn,
 * Teleport zum Spawn statt echtem Tod) funktioniert:
 *  1) tödlicher Schaden (EntityDamageEvent), 2) normales PlayerDeathEvent.
 * Ein Guard verhindert Doppelzaehlung.
 */
public final class StatsListener implements Listener {
    private static final long GUARD_MS = 2000;
    private static final long ASSIST_MS = 15000;

    private final DivineLeaderboardPlugin plugin;
    private final StatsManager stats;
    private final Map<UUID, Long> lastCounted = new HashMap<>();
    private final Map<UUID, UUID> lastAttacker = new HashMap<>();
    private final Map<UUID, Long> lastAttackTime = new HashMap<>();

    public StatsListener(DivineLeaderboardPlugin plugin, StatsManager stats) {
        this.plugin = plugin;
        this.stats = stats;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        stats.getOrCreate(p);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) stats.refresh(p);
        }, 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        stats.refresh(e.getPlayer());
        UUID id = e.getPlayer().getUniqueId();
        lastAttacker.remove(id);
        lastAttackTime.remove(id);
        lastCounted.remove(id);
    }

    private Player attackerOf(EntityDamageEvent e) {
        if (!(e instanceof EntityDamageByEntityEvent ev)) return null;
        Entity d = ev.getDamager();
        if (d instanceof Projectile pr && pr.getShooter() instanceof Player sp) return sp;
        return d instanceof Player pl ? pl : null;
    }

    /** Weg 1: tödlicher Schaden. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player victim)) return;
        Player attacker = attackerOf(e);
        if (attacker != null && !attacker.equals(victim)) {
            lastAttacker.put(victim.getUniqueId(), attacker.getUniqueId());
            lastAttackTime.put(victim.getUniqueId(), System.currentTimeMillis());
        }
        GameMode gm = victim.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) return;
        if (victim.getHealth() - e.getFinalDamage() > 0) return;
        // Totem rettet -> kein Tod
        if (victim.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || victim.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING) return;
        count(victim, attacker, "damage");
    }

    /** Weg 2: normales Todes-Event. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        count(victim, victim.getKiller(), "death-event");
    }

    private void count(Player victim, Player killer, String source) {
        long now = System.currentTimeMillis();
        Long last = lastCounted.get(victim.getUniqueId());
        if (last != null && now - last < GUARD_MS) return;   // schon gezaehlt
        lastCounted.put(victim.getUniqueId(), now);

        if (killer == null) {
            UUID id = lastAttacker.get(victim.getUniqueId());
            Long t = lastAttackTime.get(victim.getUniqueId());
            if (id != null && t != null && now - t <= ASSIST_MS) killer = plugin.getServer().getPlayer(id);
        }
        lastAttacker.remove(victim.getUniqueId());
        lastAttackTime.remove(victim.getUniqueId());

        if (stats.vanillaStats()) {
            // Minecraft zaehlt selbst -> kurz warten und neu einlesen
            final Player k = killer;
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                stats.refresh(victim);
                if (k != null) stats.refresh(k);
            }, 3L);
        } else {
            stats.addDeath(victim);
            if (killer != null && !killer.equals(victim)) stats.addKill(killer);
        }

        if (plugin.getConfig().getBoolean("debug", false)) {
            plugin.getLogger().info("[debug] Tod via " + source + ": " + victim.getName()
                    + (killer != null ? " <- " + killer.getName() : ""));
        }
    }
}
