package de.divineattack.leaderboard;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.OfflinePlayer;

/** Eigene Klasse, damit PlaceholderAPI nur geladen wird, wenn es installiert ist. */
final class PapiHook {
    private PapiHook() {}

    /** @return Zahl aus dem Platzhalter oder NaN, wenn nicht lesbar. */
    static double parse(OfflinePlayer p, String placeholder) {
        try {
            String r = PlaceholderAPI.setPlaceholders(p, placeholder);
            r = r.replaceAll("[^0-9.\\-]", "");
            if (r.isEmpty() || r.equals("-") || r.equals(".")) return Double.NaN;
            return Double.parseDouble(r);
        } catch (Throwable t) {
            return Double.NaN;
        }
    }
}
