package de.divineattack.leaderboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;

import java.util.Locale;

public enum StatType {
    KILLS("Kills", "\uE402", NamedTextColor.RED, Material.DIAMOND_SWORD),
    DEATHS("Tode", "\uE403", NamedTextColor.GRAY, Material.SKELETON_SKULL),
    MONEY("Money", "\uE401", NamedTextColor.GOLD, Material.GOLD_INGOT),
    GEMS("Gems", "\uE40B", NamedTextColor.LIGHT_PURPLE, Material.AMETHYST_SHARD);

    public final String display;
    public final String glyph;
    public final NamedTextColor color;
    public final Material material;

    StatType(String display, String glyph, NamedTextColor color, Material material) {
        this.display = display;
        this.glyph = glyph;
        this.color = color;
        this.material = material;
    }

    /** Icon aus dem Resource Pack (Font divineattack:sb). */
    public Component icon() {
        return Component.text(glyph, NamedTextColor.WHITE).font(TextUtil.SB);
    }

    public static StatType parse(String s) {
        if (s == null) return null;
        switch (s.toLowerCase(Locale.ROOT)) {
            case "kills": case "kill": return KILLS;
            case "deaths": case "death": case "tode": case "tod": return DEATHS;
            case "money": case "geld": case "coins": return MONEY;
            case "gems": case "gem": return GEMS;
            default: return null;
        }
    }
}
