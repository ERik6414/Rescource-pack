package de.divineattack.leaderboard;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public final class TextUtil {
    public static final Key LB = Key.key("divineattack", "lb");
    public static final Key SB = Key.key("divineattack", "sb");
    public static String currency = "$";

    private TextUtil() {}

    /** Breite eines Zeichens im Minecraft-Standardfont (ohne 1px Abstand). */
    private static int charWidth(char c) {
        if ("i!.,:;|'".indexOf(c) >= 0) return 1;
        if (c == 'l' || c == '`') return 2;
        if (" tI[]\"(){}*".indexOf(c) >= 0) return 3;
        if ("fk<>".indexOf(c) >= 0) return 4;
        if (c == '@' || c == '~') return 6;
        return 5;
    }

    /** Pixelbreite inkl. 1px Abstand je Zeichen. */
    public static int width(String s) {
        int w = 0;
        for (int i = 0; i < s.length(); i++) w += charWidth(s.charAt(i)) + 1;
        return w;
    }

    /** Kuerzt einen Text so, dass er maximal maxPx breit ist. */
    public static String fit(String s, int maxPx) {
        while (s.length() > 1 && width(s) > maxPx) s = s.substring(0, s.length() - 1);
        return s;
    }

    /** Unsichtbarer Abstand in Pixeln (positiv oder negativ) aus der Font divineattack:lb. */
    public static Component space(int px) {
        if (px == 0) return Component.empty();
        StringBuilder sb = new StringBuilder();
        int n = Math.abs(px);
        char base = px > 0 ? '\uE980' : '\uE990';
        while (n > 0) {
            int bit = Math.min(7, 31 - Integer.numberOfLeadingZeros(n));
            sb.append((char) (base + bit));
            n -= 1 << bit;
        }
        return Component.text(sb.toString()).font(LB);
    }

    public static Component noItalic(Component c) {
        return c.decoration(TextDecoration.ITALIC, false);
    }

    public static String integer(long v) {
        return new DecimalFormat("#,##0", DecimalFormatSymbols.getInstance(Locale.GERMANY)).format(v);
    }

    /** Volle Zahl fuer GUI / Platz-Leiste. */
    public static String full(StatType t, double v) {
        if (t == StatType.MONEY) {
            return new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.GERMANY)).format(v) + currency;
        }
        return integer((long) v);
    }

    /** Kurzform fuer die Top-10-Zeilen: 12,3K / 1,2M / 3B. */
    public static String compact(StatType t, double v) {
        String s;
        if (v >= 1_000_000_000d) s = one(v / 1_000_000_000d) + "B";
        else if (v >= 1_000_000d) s = one(v / 1_000_000d) + "M";
        else if (v >= 10_000d) s = one(v / 1_000d) + "K";
        else s = integer((long) v);
        return t == StatType.MONEY ? s + currency : s;
    }

    private static String one(double x) {
        String s = String.format(Locale.GERMANY, "%.1f", x);
        return s.endsWith(",0") ? s.substring(0, s.length() - 2) : s;
    }
}
