package de.divineattack.leaderboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;

/** Baut eine Textzeile und merkt sich die Pixelbreite, damit Spalten exakt positioniert werden koennen. */
public final class Line {
    private final TextComponent.Builder b = Component.text();
    private int x;

    public Line add(String s, TextColor c) {
        b.append(Component.text(s, c));
        x += TextUtil.width(s);
        return this;
    }

    /** Pack-Icon (9x9 px, Advance 10). */
    public Line icon(String glyph) {
        b.append(Component.text(glyph, NamedTextColor.WHITE).font(TextUtil.SB));
        x += 10;
        return this;
    }

    public Line moveTo(int target) {
        int d = target - x;
        if (d != 0) {
            b.append(TextUtil.space(d));
            x = target;
        }
        return this;
    }

    public int width() {
        return x;
    }

    public Component build() {
        return b.build();
    }

    public Component centered(int totalWidth) {
        int pad = Math.max(0, (totalWidth - x) / 2);
        return Component.text().append(TextUtil.space(pad)).append(b.build()).build();
    }
}
