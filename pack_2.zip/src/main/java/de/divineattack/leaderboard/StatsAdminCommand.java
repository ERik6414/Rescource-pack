package de.divineattack.leaderboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** /statsadmin <set|add> <kills|deaths|gems> <spieler> <menge> */
public final class StatsAdminCommand implements CommandExecutor, TabCompleter {
    private final StatsManager stats;

    public StatsAdminCommand(StatsManager stats) {
        this.stats = stats;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(Component.text("/statsadmin <set|add> <kills|deaths|gems> <spieler> <menge>", NamedTextColor.GRAY));
            return true;
        }
        boolean add = args[0].equalsIgnoreCase("add");
        if (!add && !args[0].equalsIgnoreCase("set")) {
            sender.sendMessage(Component.text("Erstes Argument: set oder add", NamedTextColor.RED));
            return true;
        }
        StatType t = StatType.parse(args[1]);
        if (t == null || t == StatType.MONEY) {
            sender.sendMessage(Component.text("Stat muss kills, deaths oder gems sein (Money l\u00E4uft \u00FCber Vault).", NamedTextColor.RED));
            return true;
        }
        PlayerStats ps = stats.findByName(args[2]);
        if (ps == null) {
            sender.sendMessage(Component.text("Spieler nicht gefunden: " + args[2], NamedTextColor.RED));
            return true;
        }
        long amount;
        try {
            amount = Long.parseLong(args[3]);
        } catch (NumberFormatException e) {
            sender.sendMessage(Component.text("Ung\u00FCltige Zahl.", NamedTextColor.RED));
            return true;
        }
        long value = add ? (long) ps.get(t) + amount : amount;
        ps.set(t, Math.max(0, value));
        sender.sendMessage(Component.text(ps.name + " \u2192 " + t.display + " = " + TextUtil.integer((long) ps.get(t)), NamedTextColor.GREEN));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("set", "add")) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2) {
            for (String s : List.of("kills", "deaths", "gems")) if (s.startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(s);
        }
        return out;
    }
}
