package de.divineattack.leaderboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.JoinConfiguration;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Hologramm-Leaderboards aus TextDisplays.
 *
 * Aufbau: Beide Displays (Panel + persoenliche "Dein Platz"-Leiste) haben exakt 22 Zeilen und stehen an derselben
 * Position. Das Panel (U+E010) belegt die Zeilen 0-18, die Platz-Leiste (U+E011) die Zeilen 19-21. Dadurch passen
 * beide immer zusammen, egal wo Minecraft das Display vertikal verankert.
 */
public final class LeaderboardManager {
    private static final int PANEL_W = 140;
    private static final int TOTAL_LINES = 22;
    private static final String TAG = "divinelb";
    private static final TextColor[] PLACE = {
            TextColor.color(0xFACC15), TextColor.color(0xCBD5E1), TextColor.color(0xCD7F32)};

    private static final class Board {
        final int id;
        final StatType type;
        final String world;
        final double x, y, z;
        final float yaw;
        UUID main;
        final Map<UUID, UUID> personal = new HashMap<>();

        Board(int id, StatType type, String world, double x, double y, double z, float yaw) {
            this.id = id;
            this.type = type;
            this.world = world;
            this.x = x;
            this.y = y;
            this.z = z;
            this.yaw = yaw;
        }

        Location location() {
            World w = Bukkit.getWorld(world);
            return w == null ? null : new Location(w, x, y, z, yaw, 0f);
        }
    }

    private final DivineLeaderboardPlugin plugin;
    private final StatsManager stats;
    private final File file;
    private final Map<Integer, Board> boards = new LinkedHashMap<>();
    private BukkitTask task;
    private int tickCount;

    public LeaderboardManager(DivineLeaderboardPlugin plugin, StatsManager stats) {
        this.plugin = plugin;
        this.stats = stats;
        this.file = new File(plugin.getDataFolder(), "boards.yml");
    }

    // ------------------------------------------------------------------ Persistenz

    public void load() {
        boards.clear();
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = y.getConfigurationSection("boards");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            ConfigurationSection b = sec.getConfigurationSection(key);
            StatType t = b == null ? null : StatType.parse(b.getString("type"));
            if (t == null) continue;
            int id = Integer.parseInt(key);
            boards.put(id, new Board(id, t, b.getString("world", "world"),
                    b.getDouble("x"), b.getDouble("y"), b.getDouble("z"), (float) b.getDouble("yaw")));
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Board b : boards.values()) {
            String p = "boards." + b.id + ".";
            y.set(p + "type", b.type.name());
            y.set(p + "world", b.world);
            y.set(p + "x", b.x);
            y.set(p + "y", b.y);
            y.set(p + "z", b.z);
            y.set(p + "yaw", b.yaw);
        }
        try {
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("boards.yml konnte nicht gespeichert werden: " + ex.getMessage());
        }
    }

    // ------------------------------------------------------------------ API fuer Commands

    public int add(StatType type, Location loc) {
        int id = boards.keySet().stream().mapToInt(Integer::intValue).max().orElse(0) + 1;
        boards.put(id, new Board(id, type, loc.getWorld().getName(), loc.getX(), loc.getY(), loc.getZ(), loc.getYaw()));
        save();
        tick(true);
        return id;
    }

    public boolean remove(int id) {
        Board b = boards.remove(id);
        if (b == null) return false;
        removeEntities(b);
        save();
        return true;
    }

    /** @return ID des naechsten Boards im Umkreis oder -1 */
    public int nearest(Location from, double radius) {
        int best = -1;
        double bestD = radius * radius;
        for (Board b : boards.values()) {
            Location l = b.location();
            if (l == null || l.getWorld() != from.getWorld()) continue;
            double d = l.distanceSquared(from);
            if (d <= bestD) {
                bestD = d;
                best = b.id;
            }
        }
        return best;
    }

    public List<String> describe() {
        List<String> out = new ArrayList<>();
        for (Board b : boards.values()) {
            out.add("#" + b.id + " " + b.type.display + " @ " + b.world + " "
                    + Math.round(b.x) + " " + Math.round(b.y) + " " + Math.round(b.z));
        }
        return out;
    }

    // ------------------------------------------------------------------ Lebenszyklus

    public void start() {
        purgeOrphans();
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> tick(false), 40L, 20L);
    }

    public void shutdown() {
        if (task != null) task.cancel();
        for (Board b : boards.values()) removeEntities(b);
        purgeOrphans();
    }

    public void reload() {
        for (Board b : boards.values()) removeEntities(b);
        load();
        tick(true);
    }

    private void purgeOrphans() {
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntitiesByClass(TextDisplay.class)) {
                if (e.getScoreboardTags().contains(TAG)) e.remove();
            }
        }
    }

    private void removeEntities(Board b) {
        removeEntity(b.main);
        b.main = null;
        for (UUID id : b.personal.values()) removeEntity(id);
        b.personal.clear();
    }

    private void removeEntity(UUID id) {
        if (id == null) return;
        Entity e = Bukkit.getEntity(id);
        if (e != null) e.remove();
    }

    private TextDisplay display(UUID id) {
        if (id == null) return null;
        Entity e = Bukkit.getEntity(id);
        return (e instanceof TextDisplay td && td.isValid()) ? td : null;
    }

    // ------------------------------------------------------------------ Tick

    private void tick(boolean forceRefresh) {
        tickCount++;
        int every = Math.max(1, plugin.getConfig().getInt("leaderboard.refresh-seconds", 20));
        boolean refresh = forceRefresh || tickCount % every == 0;
        double radius = plugin.getConfig().getDouble("leaderboard.view-radius", 40.0);

        for (Board b : boards.values()) {
            Location base = b.location();
            if (base == null) continue;
            World w = base.getWorld();
            if (!w.isChunkLoaded(base.getBlockX() >> 4, base.getBlockZ() >> 4)) continue;

            TextDisplay main = display(b.main);
            boolean fresh = false;
            if (main == null) {
                main = spawn(base, true);
                b.main = main.getUniqueId();
                fresh = true;
            }
            if (fresh || refresh) main.text(panel(b.type, stats.top(b.type, 10)));

            Set<UUID> seen = new HashSet<>();
            for (Player p : w.getPlayers()) {
                if (p.getLocation().distanceSquared(base) > radius * radius) continue;
                seen.add(p.getUniqueId());
                TextDisplay pd = display(b.personal.get(p.getUniqueId()));
                boolean isNew = false;
                if (pd == null) {
                    pd = spawn(base, false);
                    p.showEntity(plugin, pd);
                    b.personal.put(p.getUniqueId(), pd.getUniqueId());
                    isNew = true;
                }
                if (isNew || refresh) pd.text(you(b.type, p));
            }
            b.personal.entrySet().removeIf(en -> {
                if (seen.contains(en.getKey())) return false;
                removeEntity(en.getValue());
                return true;
            });
        }
    }

    private TextDisplay spawn(Location base, boolean visibleByDefault) {
        float scale = (float) plugin.getConfig().getDouble("leaderboard.scale", 0.8);
        double dy = plugin.getConfig().getDouble("leaderboard.base-height", 0.3)
                + plugin.getConfig().getDouble("leaderboard.y-offset", 0.0);
        Location at = base.clone().add(0, dy, 0);

        // Das persoenliche Display liegt sonst exakt auf derselben Ebene wie das Haupt-Panel.
        // Zwei transparente TextDisplay-Flächen auf identischen Koordinaten koennen im Client
        // gegeneinander flackern (Z-Fighting). Verschiebe nur die persoenliche Leiste minimal
        // nach vorne. Die Ausrichtung bleibt FIXED und folgt niemals der Blickrichtung.
        if (!visibleByDefault) {
            org.bukkit.util.Vector front = at.getDirection().normalize().multiply(0.04);
            at.add(front);
        }
        return at.getWorld().spawn(at, TextDisplay.class, td -> {
            td.setPersistent(false);
            td.setVisibleByDefault(visibleByDefault);
            td.addScoreboardTag(TAG);
            td.setBillboard(Display.Billboard.FIXED);
            td.setAlignment(TextDisplay.TextAlignment.LEFT);
            td.setLineWidth(1000);
            td.setShadowed(false);
            td.setSeeThrough(false);
            td.setDefaultBackground(false);
            td.setBackgroundColor(Color.fromARGB(0, 0, 0, 0));
            td.setViewRange(1.0f);
            td.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(scale, scale, scale), new AxisAngle4f()));
            td.text(Component.text(" "));
        });
    }

    // ------------------------------------------------------------------ Inhalte

    private static Component glyph(String g) {
        return Component.text(g, NamedTextColor.WHITE).font(TextUtil.LB);
    }

    private static Component blank() {
        return Component.text(" ");
    }

    private Component panel(StatType t, List<PlayerStats> top) {
        List<Component> lines = new ArrayList<>(TOTAL_LINES);
        lines.add(glyph("\uE010"));                                   // Zeile 0: Panel (Logo + Rahmen)
        for (int i = 0; i < 6; i++) lines.add(blank());               // Zeilen 1-6: Logo-Bereich

        lines.add(new Line().icon(t.glyph).add(" ", NamedTextColor.WHITE)  // Zeile 7: Titel
                .add("TOP 10 " + t.display.toUpperCase(Locale.ROOT), t.color).centered(PANEL_W));

        for (int i = 0; i < 10; i++) {                                // Zeilen 8-17: Platz 1-10
            Line l = new Line();
            String rk = String.valueOf(i + 1);
            TextColor rc = i < 3 ? PLACE[i] : NamedTextColor.GRAY;
            if (i < top.size()) {
                PlayerStats e = top.get(i);
                String val = TextUtil.compact(t, e.get(t));
                int avail = 134 - 24 - TextUtil.width(val) - 4;
                l.moveTo(19 - TextUtil.width(rk)).add(rk, rc)
                        .moveTo(24).add(TextUtil.fit(e.name, avail), NamedTextColor.WHITE)
                        .moveTo(134 - TextUtil.width(val)).add(val, t.color);
            } else {
                l.moveTo(19 - TextUtil.width(rk)).add(rk, NamedTextColor.DARK_GRAY)
                        .moveTo(24).add("-", NamedTextColor.DARK_GRAY);
            }
            lines.add(l.build());
        }

        lines.add(new Line().add("/stats  \u2022  Divine SMP", NamedTextColor.GRAY).centered(PANEL_W)); // Zeile 18
        for (int i = 0; i < 3; i++) lines.add(blank());               // Zeilen 19-21: Platz fuer die Platz-Leiste
        return Component.join(JoinConfiguration.newlines(), lines);
    }

    private Component you(StatType t, Player p) {
        PlayerStats ps = stats.getOrCreate(p);
        int rank = stats.rank(p.getUniqueId(), t);
        List<Component> lines = new ArrayList<>(TOTAL_LINES);
        for (int i = 0; i < 19; i++) lines.add(blank());              // Zeilen 0-18: leer (hier steht das Panel)
        lines.add(glyph("\uE011"));                                   // Zeile 19: Leiste
        TextColor rc = rank <= 3 ? PLACE[rank - 1] : NamedTextColor.GOLD;
        lines.add(new Line().add("Dein Platz ", NamedTextColor.GRAY).add("#" + rank, rc).centered(PANEL_W));
        lines.add(new Line().icon(t.glyph).add(" " + TextUtil.full(t, ps.get(t)), t.color).centered(PANEL_W));
        return Component.join(JoinConfiguration.newlines(), lines);
    }
}
