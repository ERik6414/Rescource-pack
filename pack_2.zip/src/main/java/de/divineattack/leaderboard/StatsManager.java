package de.divineattack.leaderboard;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;

/** Haelt alle Stats im Speicher, speichert in SQLite und berechnet Ranglisten. */
public final class StatsManager {
    private static final String UPSERT =
            "INSERT INTO stats(uuid,name,kills,deaths,money,gems) VALUES(?,?,?,?,?,?) "
                    + "ON CONFLICT(uuid) DO UPDATE SET name=excluded.name,kills=excluded.kills,"
                    + "deaths=excluded.deaths,money=excluded.money,gems=excluded.gems";

    private final DivineLeaderboardPlugin plugin;
    private final Map<UUID, PlayerStats> data = new ConcurrentHashMap<>();
    private final Map<StatType, Sorted> cache = new EnumMap<>(StatType.class);
    private final Object dbLock = new Object();
    private final String jdbcUrl;
    private Economy economy;

    private record Sorted(List<PlayerStats> list, long time) {}

    public StatsManager(DivineLeaderboardPlugin plugin) {
        this.plugin = plugin;
        plugin.getDataFolder().mkdirs();
        this.jdbcUrl = "jdbc:sqlite:" + new File(plugin.getDataFolder(), "stats.db").getAbsolutePath();
    }

    // ------------------------------------------------------------------ Datenbank

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(jdbcUrl);
    }

    public void load() {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException ignored) {
        }
        synchronized (dbLock) {
            try (Connection c = connect(); Statement st = c.createStatement()) {
                st.executeUpdate("CREATE TABLE IF NOT EXISTS stats (uuid TEXT PRIMARY KEY, name TEXT, "
                        + "kills INTEGER NOT NULL DEFAULT 0, deaths INTEGER NOT NULL DEFAULT 0, "
                        + "money REAL NOT NULL DEFAULT 0, gems INTEGER NOT NULL DEFAULT 0)");
                try (ResultSet rs = st.executeQuery("SELECT uuid,name,kills,deaths,money,gems FROM stats")) {
                    while (rs.next()) {
                        UUID id = UUID.fromString(rs.getString(1));
                        PlayerStats ps = new PlayerStats(id, rs.getString(2));
                        ps.kills = rs.getLong(3);
                        ps.deaths = rs.getLong(4);
                        ps.money = rs.getDouble(5);
                        ps.gems = rs.getLong(6);
                        data.put(id, ps);
                    }
                }
                plugin.getLogger().info(data.size() + " Spieler-Stats geladen.");
            } catch (SQLException ex) {
                plugin.getLogger().log(Level.SEVERE, "Datenbank konnte nicht geladen werden", ex);
            }
        }
    }

    /** Darf async aufgerufen werden. */
    public void saveDirty() {
        List<PlayerStats> dirty = new ArrayList<>();
        for (PlayerStats ps : data.values()) if (ps.dirty) dirty.add(ps);
        if (dirty.isEmpty()) return;
        synchronized (dbLock) {
            try (Connection c = connect(); PreparedStatement st = c.prepareStatement(UPSERT)) {
                c.setAutoCommit(false);
                for (PlayerStats ps : dirty) {
                    ps.dirty = false;
                    st.setString(1, ps.uuid.toString());
                    st.setString(2, ps.name);
                    st.setLong(3, ps.kills);
                    st.setLong(4, ps.deaths);
                    st.setDouble(5, ps.money);
                    st.setLong(6, ps.gems);
                    st.addBatch();
                }
                st.executeBatch();
                c.commit();
            } catch (SQLException ex) {
                for (PlayerStats ps : dirty) ps.dirty = true;
                plugin.getLogger().log(Level.SEVERE, "Speichern fehlgeschlagen", ex);
            }
        }
    }

    // ------------------------------------------------------------------ Zugriff

    public PlayerStats getOrCreate(UUID id, String name) {
        PlayerStats ps = data.computeIfAbsent(id, u -> {
            PlayerStats n = new PlayerStats(u, name);
            n.dirty = true;
            return n;
        });
        if (name != null && !name.equals(ps.name)) {
            ps.name = name;
            ps.dirty = true;
        }
        return ps;
    }

    public PlayerStats getOrCreate(Player p) {
        return getOrCreate(p.getUniqueId(), p.getName());
    }

    public PlayerStats get(UUID id) {
        return data.get(id);
    }

    public PlayerStats findByName(String name) {
        for (PlayerStats ps : data.values()) if (ps.name.equalsIgnoreCase(name)) return ps;
        return null;
    }

    public void addKill(Player p) {
        PlayerStats ps = getOrCreate(p);
        ps.kills++;
        ps.dirty = true;
    }

    public void addDeath(Player p) {
        PlayerStats ps = getOrCreate(p);
        ps.deaths++;
        ps.dirty = true;
    }

    /** Fuer andere Plugins: Gems aendern (nur bei gems.source = internal sinnvoll). */
    public void addGems(UUID id, long delta) {
        PlayerStats ps = getOrCreate(id, null);
        ps.gems = Math.max(0, ps.gems + delta);
        ps.dirty = true;
    }

    // ------------------------------------------------------------------ Rangliste

    private synchronized List<PlayerStats> sorted(StatType t) {
        Sorted s = cache.get(t);
        long now = System.currentTimeMillis();
        if (s == null || now - s.time() > 2000) {
            List<PlayerStats> l = new ArrayList<>(data.values());
            l.sort(Comparator.<PlayerStats>comparingDouble(p -> -p.get(t))
                    .thenComparing(p -> p.name.toLowerCase()));
            s = new Sorted(l, now);
            cache.put(t, s);
        }
        return s.list();
    }

    /** Top-N, nur Spieler mit Wert > 0. */
    public List<PlayerStats> top(StatType t, int n) {
        List<PlayerStats> out = new ArrayList<>();
        for (PlayerStats ps : sorted(t)) {
            if (out.size() >= n || ps.get(t) <= 0) break;
            out.add(ps);
        }
        return out;
    }

    public int rank(UUID id, StatType t) {
        List<PlayerStats> l = sorted(t);
        for (int i = 0; i < l.size(); i++) if (l.get(i).uuid.equals(id)) return i + 1;
        return l.size() + 1;
    }

    // ------------------------------------------------------------------ Money / Gems einlesen (Main-Thread)

    private Economy economy() {
        if (economy == null) {
            RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
            if (rsp != null) economy = rsp.getProvider();
        }
        return economy;
    }

    public boolean hasEconomy() {
        return economy() != null;
    }

    /** true = Kills/Tode aus den Minecraft-Statistiken (wie z.B. Scoreboard/PlaceholderAPI), sonst eigene Zaehlung. */
    public boolean vanillaStats() {
        return "vanilla".equalsIgnoreCase(plugin.getConfig().getString("stats.source", "vanilla"));
    }

    private boolean gemsFromPlaceholder() {
        return "placeholder".equalsIgnoreCase(plugin.getConfig().getString("gems.source", "internal"))
                && Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI");
    }

    /** Liest Money (Vault) und ggf. Gems (PlaceholderAPI) fuer einen Spieler neu ein. */
    public void refresh(OfflinePlayer op) {
        PlayerStats ps = getOrCreate(op.getUniqueId(), op.getName());
        Economy eco = economy();
        if (eco != null) {
            try {
                double b = eco.getBalance(op);
                if (b != ps.money) {
                    ps.money = b;
                    ps.dirty = true;
                }
            } catch (Throwable ignored) {
            }
        }
        if (vanillaStats()) {
            try {
                long k = op.getStatistic(Statistic.PLAYER_KILLS);
                long d = op.getStatistic(Statistic.DEATHS);
                if (k != ps.kills || d != ps.deaths) {
                    ps.kills = k;
                    ps.deaths = d;
                    ps.dirty = true;
                }
            } catch (Throwable ignored) {
            }
        }
        if (gemsFromPlaceholder()) {
            double g = PapiHook.parse(op, plugin.getConfig().getString("gems.placeholder", ""));
            if (!Double.isNaN(g) && (long) g != ps.gems) {
                ps.gems = (long) g;
                ps.dirty = true;
            }
        }
    }

    public void refreshOnline() {
        for (Player p : Bukkit.getOnlinePlayers()) refresh(p);
    }

    /** Liest alle bekannten Spieler in kleinen Haeppchen ein, damit der Server nicht laggt. */
    public void scanOffline() {
        
        final OfflinePlayer[] all = Bukkit.getOfflinePlayers();
        new BukkitRunnable() {
            int i = 0;

            @Override
            public void run() {
                int end = Math.min(all.length, i + 25);
                for (; i < end; i++) {
                    OfflinePlayer op = all[i];
                    if (op.isOnline() || op.hasPlayedBefore()) refresh(op);
                }
                if (i >= all.length) cancel();
            }
        }.runTaskTimer(plugin, 40L, 1L);
    }
}
