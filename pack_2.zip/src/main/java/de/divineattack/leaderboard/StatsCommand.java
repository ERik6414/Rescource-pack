package de.divineattack.leaderboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class StatsCommand implements CommandExecutor, TabCompleter {
    private final StatsManager stats;
    private final StatsGui gui;

    public StatsCommand(StatsManager stats, StatsGui gui) {
        this.stats = stats;
        this.gui = gui;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("Nur Spieler k\u00F6nnen /stats benutzen.");
            return true;
        }
        stats.refresh(p);
        PlayerStats target;
        if (args.length == 0) {
            target = stats.getOrCreate(p);
        } else {
            target = stats.findByName(args[0]);
            if (target == null) {
                p.sendMessage(Component.text("Spieler nicht gefunden: " + args[0], NamedTextColor.RED));
                return true;
            }
        }
        gui.openMain(p, target);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String pre = args[0].toLowerCase(Locale.ROOT);
            for (Player p : Bukkit.getOnlinePlayers()) if (p.getName().toLowerCase(Locale.ROOT).startsWith(pre)) out.add(p.getName());
        }
        return out;
    }
}
