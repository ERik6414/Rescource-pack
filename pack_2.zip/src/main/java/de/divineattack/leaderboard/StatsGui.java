package de.divineattack.leaderboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** /stats-Menue mit Custom-Hintergrund aus dem Resource Pack (Font divineattack:lb, U+E000 / U+E001). */
public final class StatsGui implements Listener {
    private static final int[] TOP_SLOTS = {11, 12, 13, 14, 15, 20, 21, 22, 23, 24};
    private static final int SLOT_PROFILE = 40;
    private static final int SLOT_BACK = 45;
    private static final int SLOT_CLOSE = 49;
    private static final TextColor[] PLACE_COLORS = {
            TextColor.color(0xFACC15), TextColor.color(0xCBD5E1), TextColor.color(0xCD7F32)};

    private enum Page { MAIN, CATEGORY }

    private static final class Holder implements InventoryHolder {
        final Page page;
        final UUID target;
        final StatType type;
        Inventory inv;

        Holder(Page page, UUID target, StatType type) {
            this.page = page;
            this.target = target;
            this.type = type;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final StatsManager stats;

    public StatsGui(StatsManager stats) {
        this.stats = stats;
    }

    private static int slotOf(StatType t) {
        return switch (t) {
            case KILLS -> 28;
            case DEATHS -> 30;
            case MONEY -> 32;
            case GEMS -> 34;
        };
    }

    private static Component title(String glyph) {
        // \uE993 = -8px (gleicht den Titel-Einzug aus), danach der Hintergrund
        return Component.text("\uE993" + glyph, NamedTextColor.WHITE).font(TextUtil.LB);
    }

    // ------------------------------------------------------------------ Seiten

    public void openMain(Player viewer, PlayerStats target) {
        Holder h = new Holder(Page.MAIN, target.uuid, null);
        Inventory inv = Bukkit.createInventory(h, 54, title("\uE000"));
        h.inv = inv;
        for (StatType t : StatType.values()) inv.setItem(slotOf(t), categoryItem(t, target));
        inv.setItem(SLOT_PROFILE, profileItem(target));
        inv.setItem(SLOT_CLOSE, closeItem());
        viewer.openInventory(inv);
    }

    public void openCategory(Player viewer, PlayerStats target, StatType type) {
        Holder h = new Holder(Page.CATEGORY, target.uuid, type);
        Inventory inv = Bukkit.createInventory(h, 54, title("\uE001"));
        h.inv = inv;
        List<PlayerStats> top = stats.top(type, 10);
        for (int i = 0; i < top.size(); i++) {
            PlayerStats e = top.get(i);
            TextColor pc = i < 3 ? PLACE_COLORS[i] : NamedTextColor.WHITE;
            List<Component> lore = new ArrayList<>();
            lore.add(Component.text().append(type.icon()).append(Component.text(" " + TextUtil.full(type, e.get(type)), type.color)).build());
            if (e.uuid.equals(target.uuid)) lore.add(Component.text("\u25C4 Das ist " + (e.uuid.equals(viewer.getUniqueId()) ? "dein Platz" : "dieser Spieler"), NamedTextColor.GREEN));
            inv.setItem(TOP_SLOTS[i], head(e.uuid, Component.text("#" + (i + 1) + " ", pc, TextDecoration.BOLD)
                    .append(Component.text(e.name, NamedTextColor.WHITE).decoration(TextDecoration.BOLD, false)), lore));
        }
        // Rang des betrachteten Spielers
        int rank = stats.rank(target.uuid, type);
        List<Component> lore = new ArrayList<>();
        lore.add(Component.text().append(type.icon()).append(Component.text(" " + TextUtil.full(type, target.get(type)), type.color)).build());
        lore.add(Component.text("Platz ", NamedTextColor.GRAY).append(Component.text("#" + rank, NamedTextColor.GOLD)));
        inv.setItem(SLOT_PROFILE, head(target.uuid, Component.text(target.name, NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD), lore));
        inv.setItem(SLOT_BACK, simple(Material.ARROW, Component.text("Zur\u00FCck", NamedTextColor.YELLOW, TextDecoration.BOLD), List.of()));
        inv.setItem(SLOT_CLOSE, closeItem());
        viewer.openInventory(inv);
    }

    // ------------------------------------------------------------------ Items

    private ItemStack categoryItem(StatType t, PlayerStats target) {
        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        lore.add(Component.text("Wert  ", NamedTextColor.GRAY).append(Component.text(TextUtil.full(t, target.get(t)), t.color)));
        lore.add(Component.text("Platz ", NamedTextColor.GRAY).append(Component.text("#" + stats.rank(target.uuid, t), NamedTextColor.GOLD)));
        lore.add(Component.empty());
        lore.add(Component.text("\u00BB Klick f\u00FCr die Top 10", NamedTextColor.DARK_GRAY));
        return simple(t.material,
                Component.text().append(t.icon()).append(Component.text(" " + t.display, t.color, TextDecoration.BOLD)).build(),
                lore);
    }

    private ItemStack profileItem(PlayerStats target) {
        List<Component> lore = new ArrayList<>();
        lore.add(Component.empty());
        for (StatType t : StatType.values()) {
            lore.add(Component.text().append(t.icon()).append(Component.text(" " + t.display + ": ", NamedTextColor.GRAY))
                    .append(Component.text(TextUtil.full(t, target.get(t)), t.color))
                    .append(Component.text("  (#" + stats.rank(target.uuid, t) + ")", NamedTextColor.DARK_GRAY)).build());
        }
        return head(target.uuid, Component.text(target.name, NamedTextColor.LIGHT_PURPLE, TextDecoration.BOLD), lore);
    }

    private ItemStack closeItem() {
        return simple(Material.BARRIER, Component.text("Schlie\u00DFen", NamedTextColor.RED, TextDecoration.BOLD), List.of());
    }

    private ItemStack head(UUID id, Component name, List<Component> lore) {
        ItemStack it = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) it.getItemMeta();
        meta.setOwningPlayer(Bukkit.getOfflinePlayer(id));
        decorate(meta, name, lore);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack simple(Material m, Component name, List<Component> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        decorate(meta, name, lore);
        it.setItemMeta(meta);
        return it;
    }

    private void decorate(ItemMeta meta, Component name, List<Component> lore) {
        meta.displayName(TextUtil.noItalic(name));
        List<Component> l = new ArrayList<>();
        for (Component c : lore) l.add(TextUtil.noItalic(c));
        meta.lore(l);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
    }

    // ------------------------------------------------------------------ Events

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;

        int slot = e.getRawSlot();
        if (slot == SLOT_CLOSE) {
            p.closeInventory();
            return;
        }
        PlayerStats target = stats.get(h.target);
        if (target == null) {
            p.closeInventory();
            return;
        }
        if (h.page == Page.MAIN) {
            for (StatType t : StatType.values()) {
                if (slot == slotOf(t)) {
                    openCategory(p, target, t);
                    return;
                }
            }
        } else if (slot == SLOT_BACK) {
            openMain(p, target);
        }
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
