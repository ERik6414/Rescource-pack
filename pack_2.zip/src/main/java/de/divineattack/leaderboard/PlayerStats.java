package de.divineattack.leaderboard;

import java.util.UUID;

public final class PlayerStats {
    public final UUID uuid;
    public volatile String name;
    public volatile long kills;
    public volatile long deaths;
    public volatile long gems;
    public volatile double money;
    public volatile boolean dirty;

    public PlayerStats(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name == null ? "?" : name;
    }

    public double get(StatType t) {
        return switch (t) {
            case KILLS -> kills;
            case DEATHS -> deaths;
            case MONEY -> money;
            case GEMS -> gems;
        };
    }

    public void set(StatType t, double v) {
        switch (t) {
            case KILLS -> kills = (long) v;
            case DEATHS -> deaths = (long) v;
            case MONEY -> money = v;
            case GEMS -> gems = (long) v;
        }
        dirty = true;
    }
}
