package de.divineattack.leaderboard;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class LeaderboardCommand implements CommandExecutor, TabCompleter {
    private final DivineLeaderboardPlugin plugin;
    private final LeaderboardManager boards;

    public LeaderboardCommand(DivineLeaderboardPlugin plugin, LeaderboardManager boards) {
        this.plugin = plugin;
        this.boards = boards;
    }

    private static void msg(CommandSender s, String text, NamedTextColor c) {
        s.sendMessage(Component.text("[Leaderboard] ", NamedTextColor.LIGHT_PURPLE).append(Component.text(text, c)));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            msg(sender, "/leaderboard spawn <kills|deaths|money|gems> | remove | list | reload", NamedTextColor.GRAY);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "spawn" -> {
                if (!(sender instanceof Player p)) {
                    msg(sender, "Nur als Spieler.", NamedTextColor.RED);
                    return true;
                }
                StatType t = args.length > 1 ? StatType.parse(args[1]) : null;
                if (t == null) {
                    msg(sender, "Nutze: /leaderboard spawn <kills|deaths|money|gems>", NamedTextColor.RED);
                    return true;
                }
                Location l = p.getLocation();
                double rad = Math.toRadians(l.getYaw());
                Location at = l.clone().add(-Math.sin(rad) * 2.5, 0, Math.cos(rad) * 2.5);
                at.setYaw(Math.round((l.getYaw() + 180f) / 15f) * 15f);
                at.setPitch(0f);
                int id = boards.add(t, at);
                msg(sender, "Leaderboard #" + id + " (" + t.display + ") erstellt.", NamedTextColor.GREEN);
            }
            case "remove" -> {
                if (!(sender instanceof Player p)) {
                    msg(sender, "Nur als Spieler.", NamedTextColor.RED);
                    return true;
                }
                int id = args.length > 1 ? parseInt(args[1]) : boards.nearest(p.getLocation(), 8);
                if (id > 0 && boards.remove(id)) msg(sender, "Leaderboard #" + id + " entfernt.", NamedTextColor.GREEN);
                else msg(sender, "Kein Leaderboard gefunden (stell dich in die N\u00E4he oder nutze /leaderboard remove <id>).", NamedTextColor.RED);
            }
            case "list" -> {
                List<String> l = boards.describe();
                if (l.isEmpty()) msg(sender, "Keine Leaderboards vorhanden.", NamedTextColor.GRAY);
                for (String s : l) msg(sender, s, NamedTextColor.WHITE);
            }
            case "reload" -> {
                plugin.reloadConfig();
                TextUtil.currency = plugin.getConfig().getString("money.symbol", "$");
                boards.reload();
                msg(sender, "Config und Leaderboards neu geladen.", NamedTextColor.GREEN);
            }
            default -> msg(sender, "Unbekannter Unterbefehl.", NamedTextColor.RED);
        }
        return true;
    }

    private static int parseInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("spawn", "remove", "list", "reload")) if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("spawn")) {
            for (String s : List.of("kills", "deaths", "money", "gems")) if (s.startsWith(args[1].toLowerCase(Locale.ROOT))) out.add(s);
        }
        return out;
    }
}
